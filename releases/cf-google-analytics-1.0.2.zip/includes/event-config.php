<?php
cf_ga_settings_nag();
echo Caldera_Forms_Processor_UI::config_fields( cf_ga_fields_events() );